public class Semaforo {
    
    private int valore;

    public Semaforo(){
        valore = 1;
    }

    public synchronized void p(){
        
        while(valore == 0){
            System.out.println("--------------" + Thread.currentThread().getName() + " in attesa al box-------------");
            try{
                wait();    
            }
            catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        valore--;
    }

    public synchronized void v(){
        notify();
        valore++;
    }


}
