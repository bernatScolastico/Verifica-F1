public class Vetture extends Thread{
    
    Box b = new Box();
    Semaforo s = new Semaforo();
    int id;
    String scuderia;

    public Vetture(String nome, int id, String scuderia, Box b, Semaforo s){
        super(nome);
        this.id = id;
        this.b = b;
        this.s = s;   
        this.scuderia = scuderia;
    }

    @Override
    public void run(){
        int durataGiro = (int) (Math.random() * 4000 + 1);
        int durataStop = (int) (Math.random() * 5000 + 1);

        for(int i=0; i<9; i++){
            try{
                Thread.sleep(durataGiro);
            }
            catch(Exception e){
                System.out.println("GARA INTERROTTA PER INCIDENTE");
            }
            System.out.println("GIRO-" + i  + " Completato " + Thread.currentThread().getName());
            if(i==2 || i==5 || i==8){
                s.p();
                b.pitStop();
                try{
                    Thread.sleep(durataStop);
                }
                catch(Exception e){
                    System.out.println("INCIDENTE NEI BOX");
                } 
                b.pitFinito();
                s.v();
            }
            
            
        }
    }
}
