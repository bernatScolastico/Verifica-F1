public class App {
    public static void main(String[] args) throws Exception {
        
        Box b = new Box();
        Semaforo s = new Semaforo();

        Vetture V1 = new Vetture ("Lecrec", 16, "Ferrari",b,s);
        Vetture V2 = new Vetture ("Perez", 11, "Red Bull",b,s);
        Vetture V3 = new Vetture ("Verstappen", 33, "Red Bull",b,s);
        Vetture V4 = new Vetture ("Hamilton", 44, "Mercedes",b,s);

        
        V1.start();
        V2.start();
        V3.start();
        V4.start();

        V1.join();
        V2.join();
        V3.join();
        V4.join();
        System.out.println("GARA FINITA");
        
    }
}
