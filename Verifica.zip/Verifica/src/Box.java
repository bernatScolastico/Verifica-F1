/**Classe Box che fa da risorsa nel programma */
public class Box {
    /**  Metodo che stampa sul terminale il pilota che è entrato nel box */
    public void pitStop(){
        System.out.println("PIT-STOP: "+Thread.currentThread().getName() + " entra nel box ------------");
        System.out.println("PIT-STOP: "+Thread.currentThread().getName() + " cambio gomme in corso -----------");
    }
    /**  Metodo che stampa sul terminale il pilota che ha finito nei box*/
    public void pitFinito(){
        System.out.println("PIT-STOP:" + Thread.currentThread().getName() + " FINITO ---------");
    }

}
